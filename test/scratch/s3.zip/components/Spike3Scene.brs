sub init()
    m.video = m.top.findNode("video")
    m.audio = m.top.findNode("audio")
    m.video.notificationInterval = 0.5
    m.video.observeField("state", "onState")
    m.clock = CreateObject("roTimespan")
    dumpFields("Video", m.video)
    dumpFields("Audio", m.audio)
    dumpFields("ContentNode", CreateObject("roSGNode", "ContentNode"))
    m.steps = [
        {name: "low", url: "http://127.0.0.1:8888/mkv/low.mkv", fmt: "mkv"},
        {name: "lowpad1", url: "http://127.0.0.1:8888/mkv/lowpad1.mkv", fmt: "mkv"},
        {name: "lowpad4", url: "http://127.0.0.1:8888/mkv/lowpad4.mkv", fmt: "mkv"},
        {name: "h05", url: "http://127.0.0.1:8888/hls/h05/live.m3u8", fmt: "hls"},
        {name: "h10", url: "http://127.0.0.1:8888/hls/h10/live.m3u8", fmt: "hls"}
    ]
    m.idx = -1
    m.task = CreateObject("roSGNode", "Spike3Task")
    m.task.observeField("ready", "nextStep")
    m.task.control = "RUN"
    m.timer = CreateObject("roSGNode", "Timer")
    m.timer.duration = 22
    m.timer.observeField("fire", "nextStep")
    m.tick = CreateObject("roSGNode", "Timer")
    m.tick.duration = 1
    m.tick.repeat = true
    m.tick.observeField("fire", "onTick")
end sub

sub dumpFields(label as string, node as object)
    keys = []
    for each k in node.getFields()
        keys.push(k)
    end for
    keys.Sort()
    print "SPIKE: fields "; label; ": "; keys.Join(",")
end sub

sub nextStep()
    m.video.control = "stop"
    m.idx = m.idx + 1
    if m.idx >= m.steps.count() then
        m.tick.control = "stop"
        print "SPIKE: all steps done"
        return
    end if
    s = m.steps[m.idx]
    m.task.step = s.name
    c = CreateObject("roSGNode", "ContentNode")
    c.url = s.url
    c.streamFormat = s.fmt
    c.live = true
    m.video.content = c
    m.clock.Mark()
    m.video.control = "play"
    print "SPIKE: === step "; s.name
    m.timer.control = "start"
    m.tick.control = "start"
end sub

sub onState()
    print "SPIKE: [" ; m.steps[m.idx].name; " t="; m.clock.TotalMilliseconds(); "] state="; m.video.state; " "; m.video.errorMsg
end sub

sub onTick()
    pos = Int(m.video.position * 1000)
    rel = m.task.releasedMs
    print "SPIKE: [" ; m.steps[m.idx].name; " t="; m.clock.TotalMilliseconds(); "] "; m.video.state; " pos_ms="; pos; " released_ms="; rel; " DEPTH_ms="; rel - pos
end sub
